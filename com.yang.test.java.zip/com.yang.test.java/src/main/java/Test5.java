public class Test5 {

	public static void main(String[] args) {
		
		double a = 23.71;
		System.out.println("10%:"+a * 1.1);
		System.out.println("9%:"+a * 1.09);
		System.out.println("8%:"+a * 1.08);
		System.out.println("7%:"+a * 1.07);
		System.out.println("6%:"+a * 1.06);
		System.out.println("5%:"+a * 1.05);
		System.out.println("4%:"+a * 1.04);
		System.out.println("3%:"+a * 1.03);
		System.out.println("2%:"+a * 1.02);
		System.out.println("1%:"+a * 1.01);
		System.out.println("-1%:"+a * 0.99);
		System.out.println("-2%:"+a * 0.98);
		System.out.println("-3%:"+a * 0.97);
		System.out.println("-4%:"+a * 0.96);
		System.out.println("-5%:"+a * 0.95);
		System.out.println("-6%:"+a * 0.94);
		System.out.println("-7%:"+a * 0.93);
		System.out.println("-8%:"+a * 0.92);
		System.out.println("-9%:"+a * 0.91);
		System.out.println("-10%:"+a * 0.9);
		
	}
}