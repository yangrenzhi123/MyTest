package com.yang.test.java.validate;

import java.util.List;

public interface BeValidatorWithMessage {

	void doValidateBySelf(List<Message> messages);
}