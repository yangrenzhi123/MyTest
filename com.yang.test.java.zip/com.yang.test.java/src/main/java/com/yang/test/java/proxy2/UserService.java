package com.yang.test.java.proxy2;

public interface UserService {

	public void say();

	public void hello();

}