package com.yang.test.java.proxy;

public interface UserService {

	public void say();

	public void hello();

}