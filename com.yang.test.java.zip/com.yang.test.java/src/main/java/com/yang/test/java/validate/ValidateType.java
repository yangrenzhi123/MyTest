package com.yang.test.java.validate;

public enum ValidateType {

	required, requierdWithMsg, length, maxLength, business, exception, startwith;

}