package com.yang.test.java.validate;

import java.util.List;

public interface BeValidator {

	public List<Message> doValidateBySelf();
}