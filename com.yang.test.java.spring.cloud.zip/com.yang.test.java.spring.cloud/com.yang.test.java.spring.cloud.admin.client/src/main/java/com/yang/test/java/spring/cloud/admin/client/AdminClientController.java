package com.yang.test.java.spring.cloud.admin.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminClientController {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(AdminClientController.class, args);
	}
}