package com.example.demo;

public interface WordService {

	String getNoun();
}